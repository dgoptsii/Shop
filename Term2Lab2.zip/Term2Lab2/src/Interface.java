import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;

public class Interface extends JFrame {
    private Shop shop;
    private Sort sort;
    private JFrame frame;

    /////////// Volodymyr's part

    //First menu
    private JPanel searchPanel;
    private JPanel buttonsPanel;
    private JTextField searchTF;
    private JButton searchB;
    private JButton add;
    private JButton edit;
    private JButton delete;
    private JButton changeQuantity;
    private JButton statistics;
    private JButton saveToFile;

    //Change quantity menu
    private JPanel upperPanelCQ;
    private JPanel centerPanelCQ;
    private JPanel lowerPanel;
    private JComboBox groupCQ;
    private JComboBox itemCQ;
    private JComboBox optionCQ;
    private JLabel quantityCQ;
    private JSpinner spinnerCQ;
    private JButton confirmCQ;
    private JButton returnCQ;

    //Save to file menu
    private JPanel upperPanelSF;
    private JPanel centerPanelSF;
    private JPanel lowerPanelSF;
    private JLabel fileNameLSF;
    private JTextField fileNameTFSF;
    private JComboBox optionVolumeSF;
    private JComboBox optionGroupsSF;
    private JButton saveSF;

    //Search menu
    private JPanel leftPanelSM;
    private JPanel rightPanelSM;
    private JScrollPane scrollItemsSM;
    private JList itemsListSM;
    private JButton showInfoSM;
    private JScrollPane infoScrollSM;
    private JLabel nameSM;
    private JLabel manufacturerSM;
    private JLabel quantitySM;
    private JLabel priceSM;
    private JTextArea descriptionSM;

    //Statistics Menu
    private JPanel centerPanelST;
    private JComboBox optionST;
    private JScrollPane scrollTableST;
    private JTable tableST;
    private DefaultTableModel tableModelST;
    private JLabel overallCostST;

    /////////// Daria`s part

    /////////CENTRAL
    private JPanel centerLeftPanel;
    private JPanel centerRightPanel;
    private JLabel nameL;
    private JLabel descriptionL;
    private JLabel manufacturerL;
    private JLabel priceL;
    private JLabel quantityL;
    private JTextField nameTF;
    private JTextArea descriptionTA;
    private JScrollPane descriptionSP;
    private JTextField manufacturerTF;
    private JSpinner spinnerQuantity;
    private JSpinner spinnerPrice;
    private JSpinner spinnerPriceCoin;

    private String name;
    private String description;
    private String manufacturer;
    private double price;
    private int quantity;
    private int choice;

    private Group groupChosen;
    private Item itemChosen;

    ///ADD MENU
    private JPanel upperPanelAdd;
    private JPanel lowerPanelAdd;
    private JComboBox groupOrItemAdd;
    private JComboBox choiceGroupAdd;
    private JButton confirmAdd;
    private JButton returnAdd;


    ///EDIT MENU
    private JPanel upperPanelEdit;
    private JPanel lowerPanelEdit;
    private JComboBox groupOrItemEdit;
    private JComboBox choiceGroupEdit;
    private JComboBox choiceItemEdit;
    private JButton confirmEdit;
    private JButton returnEdit;
    private String oldName;


    //DELETE MENU

    private JPanel upperPanelDelete;
    private JPanel lowerPanelDelete;
    private JComboBox groupOrItemDelete;
    private JComboBox choiceGroupDelete;
    private JComboBox choiceItemDelete;
    private JButton confirmDelete;
    private JButton returnDelete;
    //////////////

    /** на повернення в перше меню*/
    private JButton returnB;


    public Interface(Shop shop){

        frame = this;
        this.shop = shop;
        this.sort = new Sort();
        sort.nameToMax (this.shop);

        setUp();

        this.getContentPane().setBackground(new Color(216, 241, 233));
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setLayout(new BorderLayout());
        this.setSize(800,500);
        this.setVisible(true);
        this.setResizable(false);
        this.add(searchPanel, BorderLayout.NORTH);
        this.add(buttonsPanel, BorderLayout.CENTER);

       this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                try {
                    sort.saveData(shop);
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(frame,"DATA BASE COULD NOT BEEN SAVED!","Error",JOptionPane.ERROR_MESSAGE);
                }
                JOptionPane.showMessageDialog(frame, "Thank you for choosing our shop! ");

            }
        });
        JOptionPane.showMessageDialog(frame, "Welcome to the shop!");
    }

    /**усю ініціалізацію кидаємо сюди*/
    public void setUp(){
        initUpperPanel();
        initLowerPanel();
        initUpperPanelChangeQuantityMenu();
        initCenterPanelChangeQuantityMenu();
        initLowerPanelAllMenus();
        initUpperPanelSaveToFileMenu();
        initCenterPanelSaveToFileMenu();
        initLeftPanelSearchMenu();
        initRightPanelSearchMenu();
        initCenterPanelStatisticsMenu();

        ////////////Daria's part
        initCenterLeftPanelMenu();
        initCenterRightPanelMenu();

        initLowerPanelAddMenu();
        initUpperPanelAddMenu();

        initUpperPanelEditMenu();
        initLowerPanelEditMenu();

        initUpperPanelDeleteMenu();
        initLowerPanelDeleteMenu();
        //////////////////
    }

    private void initUpperPanel(){
        searchPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        searchPanel.setPreferredSize(new Dimension(600,100));
        searchPanel.setBackground(new Color(216, 241, 233));

        searchTF = new JTextField();
        searchTF.setPreferredSize(new Dimension(400,35));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(35,0,0,0);
        searchPanel.add(searchTF,gbc);

        searchB = new JButton("Search");
        searchB.setFont(new Font("SanSerif",Font.BOLD,13));
        searchB.setPreferredSize(new Dimension(80,32));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(35,20,0,0);
        searchPanel.add(searchB, gbc);
        searchB.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!searchTF.getText().equals("")){
                    itemsListSM.setListData(sort.findItem(searchTF.getText(),shop));
                    frame.getContentPane().removeAll();
                    frame.add(leftPanelSM,BorderLayout.WEST);
                    frame.add(lowerPanel,BorderLayout.SOUTH);
                    frame.revalidate();
                    frame.repaint();
                }else{
                    JOptionPane.showMessageDialog(frame,"You haven't entered anything!","Error",JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    private void initLowerPanel(){
        buttonsPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        buttonsPanel.setBackground(new Color(216, 241, 233));

        Font font = new Font("SanSerif",Font.BOLD,13);
        Dimension dim = new Dimension(180,32);

        add = new JButton("Add group/item");
        add.setPreferredSize(dim);
        add.setFont(font);
        gbc. gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0,0,20);
        buttonsPanel.add(add, gbc);
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.getContentPane().removeAll();
                frame.add(upperPanelAdd,BorderLayout.NORTH);
                clearChoicesAdd();
                frame.add(lowerPanelAdd,BorderLayout.SOUTH);
                frame.revalidate();
                frame.repaint();
            }
        });

        edit = new JButton("Edit group/item");
        edit.setPreferredSize(dim);
        edit.setFont(font);
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0,0,0);
        buttonsPanel.add(edit, gbc);
        edit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.getContentPane().removeAll();
                frame.add(upperPanelEdit,BorderLayout.NORTH);
                clearChoicesEdit();
                frame.add(lowerPanelEdit,BorderLayout.SOUTH);
                frame.revalidate();
                frame.repaint();

            }
        });


        delete = new JButton("Delete group/item");
        delete.setPreferredSize(dim);
        delete.setFont(font);
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,20,0,0);
        buttonsPanel.add(delete, gbc);
        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.getContentPane().removeAll();
                frame.add(upperPanelDelete,BorderLayout.CENTER);
                clearChoicesDelete();
                frame.add(lowerPanelDelete,BorderLayout.SOUTH);
                frame.revalidate();
                frame.repaint();

            }
        });


        changeQuantity = new JButton("Change the quantity of some item");
        changeQuantity.setFont(new Font("SanSerif", Font.BOLD, 16));
        changeQuantity.setPreferredSize(new Dimension(244,35));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(25,0,25,0);
        buttonsPanel.add(changeQuantity, gbc);
        changeQuantity.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.getContentPane().removeAll();
                frame.add(upperPanelCQ,BorderLayout.NORTH);
                frame.add(centerPanelCQ,BorderLayout.CENTER);
                frame.add(lowerPanel,BorderLayout.SOUTH);
                frame.revalidate();
                frame.repaint();
                if(groupCQ.getItemCount()>0){
                    groupCQ.setSelectedIndex(0);
                }
                if(itemCQ.getItemCount()>0){
                    itemCQ.setSelectedIndex(0);
                }
                if(optionCQ.getItemCount()>0){
                    optionCQ.setSelectedIndex(0);
                }
            }
        });

        statistics = new JButton("Statistics");
        statistics.setFont(font);
        statistics.setPreferredSize(dim);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.insets = new Insets(0,20,35,0);
        buttonsPanel.add(statistics, gbc);
        statistics.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] headers = {"Name","Quantity","Price per one","Total cost"};
                tableModelST.setDataVector(null,headers);
                optionST.setSelectedIndex(0);
                frame.getContentPane().removeAll();
                frame.add(centerPanelST,BorderLayout.CENTER);
                frame.add(lowerPanel,BorderLayout.SOUTH);
                frame.revalidate();
                frame.repaint();
            }
        });

        saveToFile = new JButton("Save to file");
        saveToFile.setFont(font);
        saveToFile.setPreferredSize(dim);
        gbc.gridx = 2;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.insets = new Insets(0,0,35,20);
        buttonsPanel.add(saveToFile, gbc);
        saveToFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.getContentPane().removeAll();
                frame.add(upperPanelSF,BorderLayout.NORTH);
                frame.add(centerPanelSF,BorderLayout.CENTER);
                frame.add(lowerPanel,BorderLayout.SOUTH);
                frame.revalidate();
                frame.repaint();
                if(optionGroupsSF.getSelectedIndex()!=0){
                    optionGroupsSF.setSelectedIndex(0);
                }
                if(optionVolumeSF.getSelectedIndex()!=0){
                    optionVolumeSF.setSelectedIndex(0);
                }
                fileNameTFSF.setText("");
            }
        });

    }

    private void initUpperPanelChangeQuantityMenu(){
        upperPanelCQ = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        upperPanelCQ.setPreferredSize(new Dimension(600,120));
        upperPanelCQ.setBackground(new Color(216, 241, 233));

        Font font = new Font("SanSerif",Font.BOLD,13);
        Dimension dim = new Dimension(150,30);

        itemCQ = new JComboBox();
        itemCQ.addItem("Choose an item");
        itemCQ.setFont(font);
        itemCQ.setPreferredSize(new Dimension(250,30));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(60,0,0,30);
        upperPanelCQ.add(itemCQ,gbc);
        itemCQ.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                quantityCQ.setText("Quantity of some item: _____");
                if(groupCQ.getSelectedIndex()!=0 && itemCQ.getSelectedIndex()!=0 && itemCQ.getSelectedIndex()!=-1 && optionCQ.getSelectedIndex()!=0){
                    Item item = (Item) itemCQ.getSelectedItem();
                    quantityCQ.setText(quantityCQ.getText().substring(0,quantityCQ.getText().length()-5) + item.getAmount());
                    confirmCQ.setEnabled(true);
                }else{
                    quantityCQ.setText("Quantity of some item: _____");
                    confirmCQ.setEnabled(false);
                }
            }
        });

        groupCQ = new JComboBox();
        groupCQ.addItem("Choose a group");
        for (Group group:shop.getGroupList()) {
            groupCQ.addItem(group);
        }
        groupCQ.setFont(font);
        groupCQ.setPreferredSize(dim);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(60,0,0,30);
        upperPanelCQ.add(groupCQ,gbc);
        groupCQ.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                itemCQ.removeAllItems();
                itemCQ.addItem("Choose an item");
                try{
                    Group group = (Group) groupCQ.getSelectedItem();
                    if(group!=null){
                        for (Item item : group.getArray()) {
                            itemCQ.addItem(item);
                        }
                    }
                }catch(ClassCastException ignored){}
            }
        });

        optionCQ = new JComboBox();
        optionCQ.addItem("Choose an option");
        optionCQ.addItem("Restock");
        optionCQ.addItem("Sell");
        optionCQ.setFont(font);
        optionCQ.setPreferredSize(dim);
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.insets = new Insets(60,0,0,0);
        upperPanelCQ.add(optionCQ,gbc);
        optionCQ.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                quantityCQ.setText("Quantity of some item: _____");
                if(groupCQ.getSelectedIndex()!=0 && itemCQ.getSelectedIndex()!=0 && itemCQ.getSelectedIndex()!=-1 && optionCQ.getSelectedIndex()!=0){
                    Item item = (Item) itemCQ.getSelectedItem();
                    quantityCQ.setText(quantityCQ.getText().substring(0,quantityCQ.getText().length()-5) + item.getAmount());
                    confirmCQ.setEnabled(true);
                }else{
                    quantityCQ.setText("Quantity of some item: _____");
                    confirmCQ.setEnabled(false);
                }
            }
        });
    }

    private void initCenterPanelChangeQuantityMenu(){
        centerPanelCQ = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        centerPanelCQ.setBackground(new Color(216, 241, 233));

        quantityCQ = new JLabel("Quantity of some item: _____");
        quantityCQ.setFont(new Font("SanSerif", Font.BOLD, 16));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0,50,0);
        centerPanelCQ.add(quantityCQ,gbc);

        spinnerCQ = new JSpinner(new SpinnerNumberModel(1, 1, null, 1));
        spinnerCQ.setPreferredSize(new Dimension(100,32));
        spinnerCQ.setFont(new Font("SanSerif", Font.BOLD, 14));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,125,50,75);
        centerPanelCQ.add(spinnerCQ,gbc);

        confirmCQ = new JButton("Confirm");
        confirmCQ.setPreferredSize(new Dimension(90,32));
        confirmCQ.setFont(new Font("SanSerif",Font.BOLD,14));
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0,50,0);
        centerPanelCQ.add(confirmCQ,gbc);
        confirmCQ.setEnabled(false);
        confirmCQ.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Item item = (Item) itemCQ.getSelectedItem();
                if(optionCQ.getSelectedIndex() == 1){
                    item.setAmount(item.getAmount()+(int)spinnerCQ.getValue());
                    quantityCQ.setText("Quantity of some item: " + item.getAmount());
                    JOptionPane.showMessageDialog(frame, "You have successfully restocked " + item.getName() +
                            "!\nQuantity of " + item.getName() + ": " + item.getAmount());
                }else if(optionCQ.getSelectedIndex() == 2){
                    if((int) spinnerCQ.getValue() > item.getAmount()){
                        JOptionPane.showMessageDialog(frame, "You can't sell " + spinnerCQ.getValue() + " of "
                                + item.getName() + "!\nQuantity of " + item.getName() + ": " + item.getAmount(), "Error", JOptionPane.ERROR_MESSAGE);
                    }else{
                        item.setAmount(item.getAmount()-(int)spinnerCQ.getValue());
                        quantityCQ.setText("Quantity of some item: " + item.getAmount());
                        JOptionPane.showMessageDialog(frame, "You have successfully sold " + item.getAmount() + " " + item.getName() +
                                "!\nQuantity of " + item.getName() + ": " + item.getAmount());
                    }
                }
            }
        });
    }

    private void initLowerPanelAllMenus(){
        lowerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        lowerPanel.setPreferredSize(new Dimension(600,70));
        lowerPanel.setBackground(new Color(216, 241, 233));

        returnCQ = new JButton("Return");
        returnCQ.setFont(new Font("SanSerif",Font.BOLD,14));
        gbc.gridx = 0;
        gbc.gridx = 0;
        gbc.insets = new Insets(0,530, 25,0);
        lowerPanel.add(returnCQ,gbc);
        returnCQ.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchTF.setText("");
                frame.getContentPane().removeAll();
                frame.add(searchPanel,BorderLayout.NORTH);
                frame.add(buttonsPanel,BorderLayout.CENTER);
                frame.revalidate();
                frame.repaint();
            }
        });
    }

    private void initUpperPanelSaveToFileMenu(){
        upperPanelSF = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        upperPanelSF.setPreferredSize(new Dimension(600,100));
        upperPanelSF.setBackground(new Color(216, 241, 233));

        Font font = new Font("SanSerif",Font.BOLD,13);
        Dimension dim = new Dimension(175,30);

        optionVolumeSF = new JComboBox();
        optionVolumeSF.addItem("Choose an option");
        optionVolumeSF.addItem("List of names");
        optionVolumeSF.addItem("Full information");
        optionVolumeSF.setFont(font);
        optionVolumeSF.setPreferredSize(dim);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(30,0,0,30);
        upperPanelSF.add(optionVolumeSF,gbc);
        optionVolumeSF.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(optionVolumeSF.getSelectedIndex()>0 && optionGroupsSF.getSelectedIndex()>0){
                    saveSF.setEnabled(true);
                }else{
                    saveSF.setEnabled(false);
                }
            }
        });

        optionGroupsSF = new JComboBox();
        optionGroupsSF.addItem("Choose an option");
        optionGroupsSF.addItem("One general file");
        optionGroupsSF.addItem("Separate files");
        optionGroupsSF.setFont(font);
        optionGroupsSF.setPreferredSize(dim);
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(30,0,0,300);
        upperPanelSF.add(optionGroupsSF,gbc);
        optionGroupsSF.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(optionVolumeSF.getSelectedIndex()>0 && optionGroupsSF.getSelectedIndex()>0){
                    saveSF.setEnabled(true);
                }else{
                    saveSF.setEnabled(false);
                }
            }
        });
    }

    private void initCenterPanelSaveToFileMenu(){
        centerPanelSF = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        centerPanelSF.setBackground(new Color(216, 241, 233));

        Font font = new Font("SanSerif",Font.BOLD,14);

        fileNameLSF = new JLabel("Enter a file name:");
        fileNameLSF.setFont(new Font("SanSerif",Font.BOLD,16));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0,10,345);
        centerPanelSF.add(fileNameLSF, gbc);

        fileNameTFSF = new JTextField();
        fileNameTFSF.setFont(font);
        fileNameTFSF.setPreferredSize(new Dimension(450,35));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.insets = new Insets(0,0,60,30);
        centerPanelSF.add(fileNameTFSF, gbc);

        saveSF = new JButton("Save");
        saveSF.setFont(font);
        saveSF.setPreferredSize(new Dimension(80,32));
        saveSF.setEnabled(false);
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.insets = new Insets(0,0,60,70);
        centerPanelSF.add(saveSF,gbc);
        saveSF.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!fileNameTFSF.getText().equals("") && fileNameTFSF.getText()!=null) {
                    if(optionVolumeSF.getSelectedIndex()==1 && optionGroupsSF.getSelectedIndex()==1){
                        try{
                            sort.addToOneFileShort(shop,fileNameTFSF.getText());
                            JOptionPane.showMessageDialog(frame,"You have successfully created a file.\n" +
                                    "Description: list of all groups' and items' names in one file");
                        }catch(IOException ex){
                            JOptionPane.showMessageDialog(frame,"There are forbidden characters in your file name!\n" +
                                    "The file hasn't been created!","Error",JOptionPane.ERROR_MESSAGE);
                        }
                    } else if (optionVolumeSF.getSelectedIndex()==1 && optionGroupsSF.getSelectedIndex()==2) {
                        try {
                            sort.addToDiffFilesShort(shop,fileNameTFSF.getText());
                            JOptionPane.showMessageDialog(frame,"You have successfully created the files.\n" +
                                    "Description: lists of all groups' and items' names in different files");
                        } catch (IOException ex) {
                            JOptionPane.showMessageDialog(frame,"There are forbidden characters in your file name!\n" +
                                    "The files haven't been created!","Error",JOptionPane.ERROR_MESSAGE);
                        }
                    } else if (optionVolumeSF.getSelectedIndex()==2 && optionGroupsSF.getSelectedIndex()==1) {
                        try {
                            sort.addToOneFileFull(shop,fileNameTFSF.getText());
                            JOptionPane.showMessageDialog(frame,"You have successfully created a file.\n" +
                                    "Description: all info about groups and items in one file");
                        } catch (IOException ex) {
                            JOptionPane.showMessageDialog(frame,"There are forbidden characters in your file name!\n" +
                                    "The file hasn't been created!","Error",JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        try {
                            sort.addToDiffFilesFull(shop,fileNameTFSF.getText());
                            JOptionPane.showMessageDialog(frame,"You have successfully created th files.\n" +
                                    "Description: all info about groups and items in different files");                       } catch (IOException ex) {
                            JOptionPane.showMessageDialog(frame,"There are forbidden characters in your file name!\n" +
                                    "The files haven't been created!","Error",JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }else{
                    JOptionPane.showMessageDialog(frame,"You haven't entered the name of a file!","Error",JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    private void initLeftPanelSearchMenu() {
        leftPanelSM = new JPanel(new GridBagLayout());
        leftPanelSM.setPreferredSize(new Dimension(275,500));
        GridBagConstraints gbc = new GridBagConstraints();
        leftPanelSM.setBackground(new Color(216, 241, 233));

        itemsListSM = new JList();
        itemsListSM.setFont(new Font("SanSerif",Font.BOLD,14));
        itemsListSM.setBackground(new Color(239, 255, 242));
        itemsListSM.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        itemsListSM.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if(itemsListSM.getSelectedIndex()>=0){
                    showInfoSM.setEnabled(true);
                }else{
                    showInfoSM.setEnabled(false);
                }
            }
        });

        scrollItemsSM = new JScrollPane(itemsListSM,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollItemsSM.setPreferredSize(new Dimension(245,300));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0,0,0);
        leftPanelSM.add(scrollItemsSM,gbc);

        showInfoSM = new JButton("Show information");
        showInfoSM.setFont(new Font("SanSerif",Font.BOLD,16));
        showInfoSM.setPreferredSize(new Dimension(200,40));
        showInfoSM.setEnabled(false);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.insets = new Insets(20,0,0,0);
        leftPanelSM.add(showInfoSM,gbc);
        showInfoSM.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(itemsListSM.getSelectedIndex()>=0){
                    frame.add(rightPanelSM,BorderLayout.CENTER);
                    Item item = (Item) itemsListSM.getSelectedValue();
                    nameSM.setText(item.getName());
                    priceSM.setText(String.valueOf(item.getPrice()));
                    quantitySM.setText(String.valueOf(item.getAmount()));
                    manufacturerSM.setText(item.getManufacturer());
                    descriptionSM.setText(item.getDescription());
                    frame.revalidate();
                    frame.repaint();
                }
            }
        });
    }

    private void initRightPanelSearchMenu() {
        rightPanelSM = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        rightPanelSM.setBackground(new Color(216, 241, 233));

        Font font1 = new Font("SanSerif", Font.BOLD, 16);
        Font font2 = new Font("SanSerif", Font.BOLD, 14);
        Dimension dim2 = new Dimension(300,32);
        Dimension dim1 = new Dimension(460,20);

        JLabel label;
        String[] categories = {"Name:","Quantity:","Price:","Manufacturer:","Description:"};
        for (int i = 0; i < 5; i++) {
            label = new JLabel(categories[i]);
            label.setFont(font1);
            label.setPreferredSize(dim1);
            gbc.gridx = 0;
            gbc.gridy = i*2;
            rightPanelSM.add(label,gbc);
        }

        nameSM = new JLabel("");
        nameSM.setBackground(Color.WHITE);
        nameSM.setBorder(new LineBorder(Color.BLACK));
        nameSM.setPreferredSize(dim2);
        nameSM.setFont(font2);
        nameSM.setOpaque(true);
        gbc.gridy = 1;
        gbc.insets = new Insets(0,0,10,160);
        rightPanelSM.add(nameSM,gbc);

        priceSM = new JLabel("");
        priceSM.setBackground(Color.WHITE);
        priceSM.setBorder(new LineBorder(Color.BLACK));
        priceSM.setPreferredSize(dim2);
        priceSM.setFont(font2);
        priceSM.setOpaque(true);
        gbc.gridy = 3;
        rightPanelSM.add(priceSM,gbc);

        quantitySM = new JLabel("");
        quantitySM.setBackground(Color.WHITE);
        quantitySM.setBorder(new LineBorder(Color.BLACK));
        quantitySM.setPreferredSize(dim2);
        quantitySM.setFont(font2);
        quantitySM.setOpaque(true);
        gbc.gridy = 5;
        rightPanelSM.add(quantitySM,gbc);

        manufacturerSM = new JLabel("");
        manufacturerSM.setBackground(Color.WHITE);
        manufacturerSM.setBorder(new LineBorder(Color.BLACK));
        manufacturerSM.setPreferredSize(new Dimension(460,32));
        manufacturerSM.setFont(font2);
        manufacturerSM.setOpaque(true);
        gbc.gridy = 7;
        gbc.insets = new Insets(0,0,10,0);
        rightPanelSM.add(manufacturerSM,gbc);

        descriptionSM = new JTextArea();
        descriptionSM.setEditable(false);
        descriptionSM.setFont(font2);
        descriptionSM.setLineWrap(true);
        descriptionSM.setWrapStyleWord(true);

        infoScrollSM = new JScrollPane(descriptionSM,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        infoScrollSM.setPreferredSize(new Dimension(460,120));
        gbc.gridy = 9;
        gbc.insets = new Insets(0,0,0,0);
        rightPanelSM.add(infoScrollSM,gbc);
    }

    private void initCenterPanelStatisticsMenu() {
        centerPanelST = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        centerPanelST.setBackground(new Color(216, 241, 233));

        optionST = new JComboBox();
        optionST.addItem("Choose a group");
        optionST.addItem("All groups");
        optionST.setFont(new Font("SanSerif",Font.BOLD,15));
        optionST.setPreferredSize(new Dimension(500,35));
        for (Group group:shop.getGroupList()) {
            optionST.addItem(group);
        }
        gbc.gridx = 0;
        gbc.gridy = 0;
        centerPanelST.add(optionST,gbc);
        optionST.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] headers = {"Name","Quantity","Price per one","Total cost"};
                if(optionST.getSelectedIndex()<1){
                    tableModelST.setDataVector(null,headers);
                    overallCostST.setText("");
                }else if(optionST.getSelectedIndex()==1){
                    tableModelST.setDataVector(sort.tableBodyAllItems(shop,null),headers);
                    overallCostST.setText("Overall cost: " + sort.totalCost(shop));
                }else{
                    tableModelST.setDataVector(sort.tableBodyAllItems(null,(Group)optionST.getSelectedItem()),headers);
                    overallCostST.setText("Overall cost: " + sort.costOfGroup((Group)optionST.getSelectedItem()));
                }
            }
        });

        overallCostST = new JLabel();
        overallCostST.setFont(new Font("SanSerif",Font.BOLD,16));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0,0,0);
        centerPanelST.add(overallCostST,gbc);

        String[] headers = {"Name","Quantity","Price per one","Total cost"};
        tableModelST = new DefaultTableModel(null,headers);
        tableST = new JTable(tableModelST);
        tableST.setEnabled(false);
        tableST.getTableHeader().setReorderingAllowed(false);

        scrollTableST = new JScrollPane(tableST, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollTableST.setPreferredSize(new Dimension(750,300));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(20,0,0,0);
        centerPanelST.add(scrollTableST,gbc);
    }

    ////////////////Daria`s part
    private void initUpperPanelAddMenu(){
        upperPanelAdd = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        upperPanelAdd.setPreferredSize(new Dimension(600,100));
        upperPanelAdd.setBackground(new Color(216, 241, 233));

        Font font = new Font("SanSerif",Font.BOLD,13);
        Dimension dim = new Dimension(150,30);
        String [] s ={"Choose option", "Group", "Item"};
        groupOrItemAdd = new JComboBox(s);
        groupOrItemAdd.setFont(font);
        groupOrItemAdd.setPreferredSize(new Dimension(250,30));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0,0,35);
        upperPanelAdd.add( groupOrItemAdd,gbc);
        groupOrItemAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                groupChosen=null;
                choiceGroupAdd.setSelectedIndex(0);
                choice= groupOrItemAdd.getSelectedIndex();
                nameTF.setText("");
                descriptionTA.setText("");
                manufacturerTF.setText("");
                groupChosen=null;
                choiceGroupAdd.setSelectedIndex(0);
                spinnerPrice.setValue(0);
                spinnerPriceCoin.setValue(0);
                choiceGroupAdd.setVisible(false);
                confirmAdd.setEnabled(false);


                if( groupOrItemAdd.getSelectedIndex()==0){

                    frame.getContentPane().remove(centerLeftPanel);
                    frame.getContentPane().remove(centerRightPanel);
                    frame.revalidate();
                    frame.repaint();

                }
                else  if( groupOrItemAdd.getSelectedIndex()==1){
                    confirmAdd.setEnabled(true);


                    frame.getContentPane().remove(centerRightPanel);
                    frame.getContentPane().remove(centerLeftPanel);
                    frame.add(centerLeftPanel,BorderLayout.CENTER);
                    frame.revalidate();
                    frame.repaint();

                } else if( groupOrItemAdd.getSelectedIndex()==2){
                    confirmAdd.setEnabled(true);
                    choiceGroupAdd.setVisible(true);
                    frame.getContentPane().remove(centerRightPanel);
                    frame.getContentPane().remove(centerLeftPanel);
                    frame.add(centerLeftPanel,BorderLayout.WEST);
                    frame.add(centerRightPanel,BorderLayout.CENTER);
                    frame.revalidate();
                    frame.repaint();

                    if (shop.getArray().length==0) {
                        JOptionPane.showMessageDialog(frame,"No groups found! Create group first!","Error",JOptionPane.ERROR_MESSAGE);
                        groupOrItemAdd.setSelectedIndex(1);
                        confirmAdd.setEnabled(true);


                        frame.getContentPane().remove(centerRightPanel);
                        frame.getContentPane().remove(centerLeftPanel);
                        frame.add(centerLeftPanel,BorderLayout.CENTER);
                        frame.revalidate();
                        frame.repaint();

                        groupChosen=null;
                        choiceGroupAdd.setSelectedIndex(0);
                        choice= groupOrItemAdd.getSelectedIndex();
                        nameTF.setText("");
                        descriptionTA.setText("");
                        manufacturerTF.setText("");
                        groupChosen=null;
                        choiceGroupAdd.setSelectedIndex(0);
                        spinnerPrice.setValue(0);
                        spinnerPriceCoin.setValue(0);
                        choiceGroupAdd.setVisible(false);
                    }


                }
            }
        });

        choiceGroupAdd = new JComboBox();
        choiceGroupAdd.addItem("Choose a group");

        for (Group group:shop.getGroupList()) {
            choiceGroupAdd.addItem(group);
        }
        choiceGroupAdd.setFont(font);
        choiceGroupAdd.setPreferredSize(new Dimension(250,30));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,20,0,0);
        upperPanelAdd.add(choiceGroupAdd,gbc);
        choiceGroupAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if ( choiceGroupAdd.getSelectedIndex()!=0) {
                    groupChosen = (Group) choiceGroupAdd.getSelectedItem();

                }
                else{
                    groupChosen=null;
                }

            }
        });

    }
    private void initCenterLeftPanelMenu() {
        centerLeftPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        centerLeftPanel.setPreferredSize(new Dimension(350, 100));
        centerLeftPanel.setBackground(new Color(216, 241, 233));

        Font font = new Font("SanSerif", Font.BOLD, 13);
        Dimension dim = new Dimension(150, 30);

        nameL = new JLabel();
        nameL.setFont(new Font("SanSerif", Font.BOLD, 14));
        nameL.setText("Name:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 5, 0, 0);
        centerLeftPanel.add(nameL, gbc);


        nameTF = new JTextField();
        nameTF.setFont(new Font("SanSerif", Font.BOLD, 14));
        nameTF.setPreferredSize(new Dimension(300, 35));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth=2;
        gbc.insets = new Insets(0, 0, 0, 0);
        centerLeftPanel.add(nameTF, gbc);


        descriptionL = new JLabel();
        descriptionL.setFont(new Font("SanSerif", Font.BOLD, 14));
        descriptionL.setText("Description:");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.insets = new Insets(10, 0, 0, 220);
        centerLeftPanel.add(descriptionL, gbc);


        descriptionTA = new JTextArea();
        descriptionTA.setFont(new Font("SanSerif", Font.BOLD, 14));
        descriptionTA.setLineWrap(true);
        descriptionTA.setWrapStyleWord(true);

        descriptionSP = new JScrollPane(descriptionTA, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        descriptionSP.setPreferredSize(new Dimension(300, 200));
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.insets = new Insets(10, 0, 0, 0);
        centerLeftPanel.add(descriptionSP, gbc);
    }

    private void initCenterRightPanelMenu(){
        centerRightPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        centerRightPanel.setPreferredSize(new Dimension(350, 120));
        centerRightPanel.setBackground(new Color(216, 241, 233));

        Font font = new Font("SanSerif", Font.BOLD, 13);
        Dimension dim = new Dimension(150, 30);

        manufacturerL = new JLabel();
        manufacturerL.setFont(new Font("SanSerif", Font.BOLD, 14));
        manufacturerL.setText("Manufacturer:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 4, 0);
        centerRightPanel.add(manufacturerL, gbc);


        manufacturerTF = new JTextField();
        manufacturerTF.setFont(new Font("SanSerif", Font.BOLD, 14));
        manufacturerTF.setPreferredSize(new Dimension(350, 35));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth=2;
        gbc.insets = new Insets(0, 0, 0, 0);


        centerRightPanel.add( manufacturerTF, gbc);

        priceL = new JLabel();
        priceL.setFont(new Font("SanSerif", Font.BOLD, 14));
        priceL.setText("Price:");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.insets = new Insets(20, 0, 0, 310);
        centerRightPanel.add(priceL, gbc);

        spinnerPrice = new JSpinner(new SpinnerNumberModel(0, 0, null, 1));
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth=2;
        gbc.fill=GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 0, 0);
        centerRightPanel.add(spinnerPrice, gbc);

        spinnerPriceCoin = new JSpinner(new SpinnerNumberModel(0, 0, 99, 1));
       // spinnerPriceCoinAdd.setPreferredSize(new Dimension(20, 10));
        gbc.gridx = 2;
        gbc.gridy = 3;
        centerRightPanel.add(spinnerPriceCoin, gbc);
        gbc.insets = new Insets(10, 0, 0, 0);

        quantityL = new JLabel();
        quantityL.setFont(new Font("SanSerif", Font.BOLD, 14));
        quantityL.setText("Quantity:");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.insets = new Insets(20, 0, 0, 0);
        centerRightPanel.add(quantityL, gbc);

        spinnerQuantity = new JSpinner(new SpinnerNumberModel(0, 0, null, 1));
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth=2;
        gbc.fill=GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 0, 0);
        centerRightPanel.add(spinnerQuantity, gbc);



    }

    private void initLowerPanelAddMenu(){
        lowerPanelAdd = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        lowerPanelAdd.setPreferredSize(new Dimension(600,70));
        lowerPanelAdd.setBackground(new Color(216, 241, 233));

        returnAdd = new JButton("Return");
        returnAdd.setFont(new Font("SanSerif",Font.BOLD,14));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,100, 0,0);
        lowerPanelAdd.add(returnAdd,gbc);
        returnAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearChoicesAdd();
                frame.getContentPane().removeAll();
                frame.add(searchPanel,BorderLayout.NORTH);
                frame.add(buttonsPanel,BorderLayout.CENTER);
                frame.revalidate();
                frame.repaint();
            }
        });



        confirmAdd = new JButton("ADD");
        confirmAdd.setFont(new Font("SanSerif",Font.BOLD,14));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0, 0,100);
        lowerPanelAdd.add( confirmAdd,gbc);
        confirmAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                name = nameTF.getText();
                String help ="";
                for (int i=0; i<name.length(); i++){
                    if  (i==0){
                        help+=Character.toUpperCase(name.charAt(i));
                    }
                    else{
                        help+=Character.toLowerCase(name.charAt(i));
                    }
                }
                name=help;
                description = descriptionTA.getText();
                manufacturer = manufacturerTF.getText();
                String priceV = "" + (int) spinnerPrice.getValue() + "." ;
                String s = ""+(int) spinnerPriceCoin.getValue();
                if (s.matches("[0-9]")){
                    priceV+="0"+s;
                }else{
                    priceV+=s;
                }
                price = Double.valueOf(priceV);
                String quantityV = "" + (int) spinnerQuantity.getValue();
                quantity = Integer.valueOf(quantityV);
                price = Double.valueOf(priceV);
                boolean sameAsGroup=false;
                if (choice==2) {
                    for (int i = 0; i < shop.getArray().length; i++) {
                        if (name.equals(shop.getArray()[i].getName())){
                            sameAsGroup=true;
                        }
                    }
                }


                if (groupChosen==null&& choice==2){
                    JOptionPane.showMessageDialog(frame,"You need to choose group!","Error",JOptionPane.ERROR_MESSAGE);
                }
                else if (name.length()==0){
                    JOptionPane.showMessageDialog(frame,"Name can`t be empty! Enter again!","Error",JOptionPane.ERROR_MESSAGE);
                }else if(name.matches("[A-aZ-zА-аЯ-яЇїҐґЄєІі]+[A-aZ-zА-аЯ-яЇїҐґЄєІі 0-9]*")==false) {
                    JOptionPane.showMessageDialog(frame,"Name may start with letter, contain letters, numbers, symbols only! Enter again!","Error",JOptionPane.ERROR_MESSAGE);
                    nameTF.setText("");
                }else if(sort.groupIsUnique(shop, name)==false&& choice==1) {
                    JOptionPane.showMessageDialog(frame,"Such group already exist! Enter again!","Error",JOptionPane.ERROR_MESSAGE);
                    nameTF.setText("");
                }
                else if(sort.itemIsUnique(shop, name)==false&& choice==2) {
                    JOptionPane.showMessageDialog(frame,"Such item already exist! Enter again!","Error",JOptionPane.ERROR_MESSAGE);
                    nameTF.setText("");
                }
                else if (sameAsGroup){
                    JOptionPane.showMessageDialog(frame,"Item can't have same name as any of the groups! Enter again!","Error",JOptionPane.ERROR_MESSAGE);
                    nameTF.setText("");
                }
                else if(description.length()==0) {
                    JOptionPane.showMessageDialog(frame,"Description can't be empty! Enter again!","Error",JOptionPane.ERROR_MESSAGE);
                }else if(manufacturer.length()==0 && choice==2) {
                    JOptionPane.showMessageDialog(frame,"Manufacturer cant be empty! Enter again!","Error",JOptionPane.ERROR_MESSAGE);
                } else if(price<0.1&& choice==2) {
                    JOptionPane.showMessageDialog(frame,"Price can't be zero! Enter again!","Error",JOptionPane.ERROR_MESSAGE);
                }else{
                    if (choice==1) {
                        Group newGroup = new Group(name, description);
                        shop.addArray(newGroup);
                        sort.nameToMax (shop);
                        JOptionPane.showMessageDialog(frame,"Group "+newGroup.getName()+" added!");

                        groupCQ.removeAllItems();
                        groupCQ.addItem("Choose a group");
                        for (Group group:shop.getGroupList()) {
                            groupCQ.addItem(group);
                        }

                        initCenterPanelStatisticsMenu();
                        initUpperPanelAddMenu();
                        initUpperPanelEditMenu();
                        initUpperPanelDeleteMenu();

                    }
                    else if (choice==2) {
                        Item newItem = new Item(name, description, manufacturer, price, quantity);
                        groupChosen.addArray(newItem);
                        sort.nameToMax (shop);
                        JOptionPane.showMessageDialog(frame,"Item "+newItem.getName()+" added to group "+groupChosen+"!");

                    }

                    frame.getContentPane().removeAll();
                    frame.add(upperPanelAdd,BorderLayout.NORTH);
                    clearChoicesAdd();
                    frame.add(lowerPanelAdd,BorderLayout.SOUTH);
                    frame.revalidate();
                    frame.repaint();

                }

            }
        });
    }



    private void initUpperPanelEditMenu(){

        upperPanelEdit = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        upperPanelEdit.setPreferredSize(new Dimension(600,100));
        upperPanelEdit.setBackground(new Color(216, 241, 233));

        Font font = new Font("SanSerif",Font.BOLD,13);
        Dimension dim = new Dimension(150,30);
        String [] s ={"Choose option", "Group", "Item"};
        groupOrItemEdit = new JComboBox(s);
        groupOrItemEdit.setFont(font);
        groupOrItemEdit.setPreferredSize(new Dimension(250,30));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0,0,0);
        upperPanelEdit.add( groupOrItemEdit,gbc);
        groupOrItemEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                groupChosen=null;
                itemChosen=null;
                oldName="";
                choiceGroupEdit.setSelectedIndex(0);
                choice= groupOrItemEdit.getSelectedIndex();
                nameTF.setText("");
                descriptionTA.setText("");
                manufacturerTF.setText("");
                choiceGroupEdit.setSelectedIndex(0);
                spinnerPrice.setValue(0);
                spinnerPriceCoin.setValue(0);
                spinnerQuantity.setValue(0);
                choiceGroupEdit.setVisible(false);
                choiceItemEdit.setVisible(false);
                choiceItemEdit.setVisible(false);
                confirmEdit.setEnabled(false);

                nameTF.setEnabled(false);
                descriptionTA.setEnabled(false);
                manufacturerTF.setEnabled(false);
                spinnerPrice.setEnabled(false);
                spinnerPriceCoin.setEnabled(false);
                spinnerQuantity.setEnabled(false);

                if( groupOrItemEdit.getSelectedIndex()==0){

                    frame.getContentPane().remove(centerLeftPanel);
                    frame.getContentPane().remove(centerRightPanel);
                    frame.revalidate();
                    frame.repaint();

                }
                else  if( groupOrItemEdit.getSelectedIndex()==1){
                    confirmEdit.setEnabled(true);
                    choiceGroupEdit.setVisible(true);

                    frame.getContentPane().remove(centerRightPanel);
                    frame.getContentPane().remove(centerLeftPanel);
                    frame.add(centerLeftPanel,BorderLayout.CENTER);
                    frame.revalidate();
                    frame.repaint();

                    if (shop.getArray().length==0) {
                        JOptionPane.showMessageDialog(frame,"No groups found! Create group first!","Error",JOptionPane.ERROR_MESSAGE);
                        confirmEdit.setEnabled(false);
                    }

                } else if( groupOrItemEdit.getSelectedIndex()==2){
                    confirmEdit.setEnabled(true);
                   choiceGroupEdit.setVisible(true);
                    choiceItemEdit.setVisible(true);
                    frame.getContentPane().remove(centerRightPanel);
                    frame.getContentPane().remove(centerLeftPanel);
                    frame.add(centerLeftPanel,BorderLayout.WEST);
                    frame.add(centerRightPanel,BorderLayout.CENTER);
                    frame.revalidate();
                    frame.repaint();
                    if (shop.getArray().length==0) {
                        JOptionPane.showMessageDialog(frame,"No groups found! Create group first!","Error",JOptionPane.ERROR_MESSAGE);
                        confirmEdit.setEnabled(false);
                    }


                }
            }
        });

        choiceGroupEdit = new JComboBox();
        choiceGroupEdit.addItem("Choose a group");

        for (Group group:shop.getGroupList()) {
            choiceGroupEdit.addItem(group);
        }
        choiceGroupEdit.setFont(font);
        choiceGroupEdit.setPreferredSize(new Dimension(250,30));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0,0,0);
        upperPanelEdit.add(choiceGroupEdit,gbc);
        choiceGroupEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if ( choiceGroupEdit.getSelectedIndex()!=0) {
                    confirmEdit.setEnabled(true);
                        groupChosen = (Group) choiceGroupEdit.getSelectedItem();
                        if (groupChosen.getArray().length == 0&&choice==2) {
                            JOptionPane.showMessageDialog(frame, "No items in this group found! Create item first!", "Error", JOptionPane.ERROR_MESSAGE);
                            confirmEdit.setEnabled(false);
                        }

                        choiceItemEdit.removeAllItems();
                        choiceItemEdit.addItem("Choose an item");
                        for (Item item : groupChosen.getArray()) {
                            choiceItemEdit.addItem(item);
                    }
                    if (choice==1){
                        nameTF.setText(groupChosen.getName());
                        oldName=groupChosen.getName();
                        descriptionTA.setText(groupChosen.getDescription());
                        nameTF.setEnabled(true);
                        descriptionTA.setEnabled(true);
                    }

                }
                else{
                    groupChosen=null;
                    itemChosen=null;
                    choiceItemEdit.removeAllItems();
                    choiceItemEdit.addItem("Choose an item");
                    nameTF.setText("");
                    oldName="";
                    descriptionTA.setText("");

                    nameTF.setEnabled(false);
                    descriptionTA.setEnabled(false);

                }

            }
        });



        choiceItemEdit = new JComboBox();
        choiceItemEdit.addItem("Choose a item");


        choiceItemEdit.setFont(font);
        choiceItemEdit.setPreferredSize(new Dimension(250,30));
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0,0,0);
        upperPanelEdit.add(choiceItemEdit,gbc);
        choiceItemEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              if ( choiceItemEdit.getSelectedIndex()!=0) {
                  itemChosen = (Item) choiceItemEdit.getSelectedItem();
                  if ( itemChosen!=null) {

                        nameTF.setText(itemChosen.getName());
                      oldName=itemChosen.getName();
                        descriptionTA.setText(itemChosen.getDescription());
                      manufacturerTF.setText(itemChosen.getManufacturer());
                        String s = "" + itemChosen.getPrice();
                        String first="";
                        String second="";
                        boolean beforeDot=true;
                        for(int i=0;i<s.length();i++){
                            if (s.charAt(i)=='.'){
                                beforeDot=false;
                                continue;
                            }
                            if (beforeDot==true){
                                first+=s.charAt(i);
                            }
                            else{
                                second+=s.charAt(i);
                            }
                        }
                        int firstInt=Integer.valueOf(first);

                      int secondInt = Integer.valueOf(second);
                      if (second.matches("[0-9]")){
                          secondInt=secondInt*10;
                      }
                         spinnerPrice.setValue(firstInt);
                    spinnerPriceCoin.setValue(secondInt);
                        spinnerQuantity.setValue(itemChosen.getAmount());



                      nameTF.setEnabled(true);
                      descriptionTA.setEnabled(true);
                      manufacturerTF.setEnabled(true);
                      spinnerPrice.setEnabled(true);
                      spinnerPriceCoin.setEnabled(true);
                      spinnerQuantity.setEnabled(true);
                     }

                }
                else{
                    itemChosen=null;
                  nameTF.setText("");
                  oldName="";
                  descriptionTA.setText("");
                  manufacturerTF.setText("");
                  spinnerPrice.setValue(0);
                  spinnerPriceCoin.setValue(0);
                  spinnerQuantity.setValue(0);

                  nameTF.setEnabled(false);
                  descriptionTA.setEnabled(false);
                  manufacturerTF.setEnabled(false);
                  spinnerPrice.setEnabled(false);
                  spinnerPriceCoin.setEnabled(false);
                  spinnerQuantity.setEnabled(false);
                }
            }
        });

    }

    private void initLowerPanelEditMenu(){
        lowerPanelEdit = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        lowerPanelEdit.setPreferredSize(new Dimension(600,70));
        lowerPanelEdit.setBackground(new Color(216, 241, 233));

        returnEdit = new JButton("Return");
        returnEdit.setFont(new Font("SanSerif",Font.BOLD,14));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,100, 0,0);
        lowerPanelEdit.add(returnEdit,gbc);
        returnEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearChoicesEdit();
                frame.getContentPane().removeAll();
                frame.add(searchPanel,BorderLayout.NORTH);
                frame.add(buttonsPanel,BorderLayout.CENTER);
                frame.revalidate();
                frame.repaint();
            }
        });



        confirmEdit = new JButton("EDIT");
        confirmEdit.setFont(new Font("SanSerif",Font.BOLD,14));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0, 0,100);
        lowerPanelEdit.add( confirmEdit,gbc);
        confirmEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                name = nameTF.getText();
                String help ="";
                for (int i=0; i<name.length(); i++){
                    if  (i==0){
                        help+=Character.toUpperCase(name.charAt(i));
                    }
                    else{
                        help+=Character.toLowerCase(name.charAt(i));
                    }
                }
                name=help;
                description = descriptionTA.getText();
                manufacturer = manufacturerTF.getText();
                String priceV = "" + (int) spinnerPrice.getValue() + "." ;
                String s = ""+(int) spinnerPriceCoin.getValue();
                if (s.matches("[0-9]")){
                    priceV+="0"+s;
                }else{
                    priceV+=s;
                }
                price = Double.valueOf(priceV);
                String quantityV = "" + (int) spinnerQuantity.getValue();
                quantity = Integer.valueOf(quantityV);
                price = Double.valueOf(priceV);
                boolean sameAsGroup=false;
                if (choice==2) {
                    for (int i = 0; i < shop.getArray().length; i++) {
                        if (name.equals(shop.getArray()[i].getName())){
                            sameAsGroup=true;
                        }
                    }
                }




                if (groupChosen==null&& choice==1){
                    JOptionPane.showMessageDialog(frame,"You need to choose group!","Error",JOptionPane.ERROR_MESSAGE);
                }
                else if (groupChosen==null&& choice==2){
                    JOptionPane.showMessageDialog(frame,"You need to choose group!","Error",JOptionPane.ERROR_MESSAGE);
                }
                else if (itemChosen==null&& choice==2){
                    JOptionPane.showMessageDialog(frame,"You need to choose item!","Error",JOptionPane.ERROR_MESSAGE);
                }else if (name.length()==0){
                    JOptionPane.showMessageDialog(frame,"Name can`t be empty! Enter again!","Error",JOptionPane.ERROR_MESSAGE);
                }else if(name.matches("[A-aZ-zА-аЯ-яЇїҐґЄєІі]+[A-aZ-zА-аЯ-яЇїҐґЄєІі 0-9]*")==false) {
                    JOptionPane.showMessageDialog(frame,"Name may start with letter, contain letters, numbers, symbols only! Enter again!","Error",JOptionPane.ERROR_MESSAGE);
                    nameTF.setText("");
                }else if(sort.groupIsUnique(shop, name)==false&& choice==1&&name.equals(oldName)==false) {
                    JOptionPane.showMessageDialog(frame,"Such group already exist! Enter again!","Error",JOptionPane.ERROR_MESSAGE);
                    nameTF.setText("");
                }
                else if(sort.itemIsUnique(shop, name)==false&& choice==2&&name.equals(oldName)==false) {
                    JOptionPane.showMessageDialog(frame,"Such item already exist! Enter again!","Error",JOptionPane.ERROR_MESSAGE);
                    nameTF.setText("");
                }
                else if (sameAsGroup){
                    JOptionPane.showMessageDialog(frame,"Item can't have same name as any of the groups! Enter again!","Error",JOptionPane.ERROR_MESSAGE);
                    nameTF.setText("");
                }
                else if(description.length()==0) {
                    JOptionPane.showMessageDialog(frame,"Description can't be empty! Enter again!","Error",JOptionPane.ERROR_MESSAGE);
                }else if(manufacturer.length()==0 && choice==2) {
                    JOptionPane.showMessageDialog(frame,"Manufacturer cant be empty! Enter again!","Error",JOptionPane.ERROR_MESSAGE);
                } else if(price<0.1&& choice==2) {
                    JOptionPane.showMessageDialog(frame,"Price can't be zero! Enter again!","Error",JOptionPane.ERROR_MESSAGE);
                }else{
                    if (choice==1) {
                       groupChosen.setName(name);
                       groupChosen.setDescription(description);
                        sort.nameToMax (shop);
                        JOptionPane.showMessageDialog(frame,"Group edited!");

                        groupCQ.removeAllItems();
                        groupCQ.addItem("Choose a group");
                        for (Group group:shop.getGroupList()) {
                            groupCQ.addItem(group);
                        }

                        initCenterPanelStatisticsMenu();
                        initUpperPanelAddMenu();
                        initUpperPanelEditMenu();
                        initUpperPanelDeleteMenu();

                    }
                    else if (choice==2) {
                        itemChosen.setName(name);
                        itemChosen.setDescription(description);
                        itemChosen.setManufacturer(manufacturer);
                        itemChosen.setPrice(price);
                        itemChosen.setAmount(quantity);
                        sort.nameToMax (shop);
                        JOptionPane.showMessageDialog(frame,"Item edited!");

                    }

                    frame.getContentPane().removeAll();
                    frame.add(upperPanelEdit,BorderLayout.NORTH);
                    clearChoicesEdit();
                    frame.add(lowerPanelEdit,BorderLayout.SOUTH);
                    frame.revalidate();
                    frame.repaint();
                }

            }
        });
    }

    private void initUpperPanelDeleteMenu(){

        upperPanelDelete = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        upperPanelDelete.setPreferredSize(new Dimension(600,100));
        upperPanelDelete.setBackground(new Color(216, 241, 233));

        Font font = new Font("SanSerif",Font.BOLD,13);
        Dimension dim = new Dimension(150,30);
        String [] s ={"Choose option", "Group", "Item"};
        groupOrItemDelete = new JComboBox(s);
        groupOrItemDelete.setFont(font);
        groupOrItemDelete.setPreferredSize(new Dimension(250,30));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0,0,0);
        upperPanelDelete.add( groupOrItemDelete,gbc);
        groupOrItemDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                groupChosen=null;
                itemChosen=null;
                choiceGroupDelete.setSelectedIndex(0);
                choice= groupOrItemDelete.getSelectedIndex();
                choiceGroupDelete.setSelectedIndex(0);
                choiceGroupDelete.setVisible(false);
                choiceItemDelete.setVisible(false);
                choiceItemDelete.setVisible(false);
                confirmDelete.setEnabled(false);

                if( groupOrItemDelete.getSelectedIndex()==0){

                    frame.getContentPane().remove(centerLeftPanel);
                    frame.getContentPane().remove(centerRightPanel);
                    frame.revalidate();
                    frame.repaint();

                }
                else  if( groupOrItemDelete.getSelectedIndex()==1){
                    confirmDelete.setEnabled(true);
                    choiceGroupDelete.setVisible(true);

                    frame.getContentPane().remove(centerRightPanel);
                    frame.getContentPane().remove(centerLeftPanel);
                    frame.revalidate();
                    frame.repaint();

                    if (shop.getArray().length==0) {
                        JOptionPane.showMessageDialog(frame,"No groups found! Create group first!","Error",JOptionPane.ERROR_MESSAGE);
                        confirmDelete.setEnabled(false);
                    }

                } else if( groupOrItemDelete.getSelectedIndex()==2){
                    confirmDelete.setEnabled(true);
                    choiceGroupDelete.setVisible(true);
                    choiceItemDelete.setVisible(true);
                    frame.getContentPane().remove(centerRightPanel);
                    frame.getContentPane().remove(centerLeftPanel);
                    frame.revalidate();
                    frame.repaint();
                    if (shop.getArray().length==0) {
                        JOptionPane.showMessageDialog(frame,"No groups found! Create group first!","Error",JOptionPane.ERROR_MESSAGE);
                        confirmDelete.setEnabled(false);
                    }


                }
            }
        });

        choiceGroupDelete = new JComboBox();
        choiceGroupDelete.addItem("Choose a group");

        for (Group group:shop.getGroupList()) {
            choiceGroupDelete.addItem(group);
        }
        choiceGroupDelete.setFont(font);
        choiceGroupDelete.setPreferredSize(new Dimension(250,30));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0,0,0);
        upperPanelDelete.add(choiceGroupDelete,gbc);
        choiceGroupDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if ( choiceGroupDelete.getSelectedIndex()!=0) {
                    confirmDelete.setEnabled(true);

                    groupChosen = (Group) choiceGroupDelete.getSelectedItem();
                    if (groupChosen.getArray().length==0&&choice==2) {
                        JOptionPane.showMessageDialog(frame,"No items in this group found! Create item first!","Error",JOptionPane.ERROR_MESSAGE);
                        confirmDelete.setEnabled(false);
                    }
                    choiceItemDelete.removeAllItems();
                    choiceItemDelete.addItem("Choose an item");
                    for (Item item : groupChosen.getArray()) {
                        choiceItemDelete.addItem(item);
                    }


                }
                else{
                    groupChosen=null;
                    itemChosen=null;
                    choiceItemDelete.removeAllItems();
                    choiceItemDelete.addItem("Choose an item");


                }

            }
        });



        choiceItemDelete = new JComboBox();
        choiceItemDelete.addItem("Choose a item");


        choiceItemDelete.setFont(font);
        choiceItemDelete.setPreferredSize(new Dimension(250,30));
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0,0,0);
        upperPanelDelete.add(choiceItemDelete,gbc);
        choiceItemDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if ( choiceItemDelete.getSelectedIndex()!=0) {
                    itemChosen = (Item) choiceItemDelete.getSelectedItem();

                }
                else{
                    itemChosen=null;

                }
            }
        });

    }


    private void initLowerPanelDeleteMenu(){
        lowerPanelDelete = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        lowerPanelDelete.setPreferredSize(new Dimension(600,70));
        lowerPanelDelete.setBackground(new Color(216, 241, 233));

        returnDelete = new JButton("Return");
        returnDelete.setFont(new Font("SanSerif",Font.BOLD,14));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,100, 0,0);
        lowerPanelDelete.add(returnDelete,gbc);
        returnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearChoicesDelete();
                frame.getContentPane().removeAll();
                frame.add(searchPanel,BorderLayout.NORTH);
                frame.add(buttonsPanel,BorderLayout.CENTER);
                frame.revalidate();
                frame.repaint();
            }
        });



        confirmDelete = new JButton("DELETE");
        confirmDelete.setFont(new Font("SanSerif",Font.BOLD,14));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0, 0,100);
        lowerPanelDelete.add( confirmDelete,gbc);
        confirmDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (groupChosen==null&& choice==1){
                    JOptionPane.showMessageDialog(frame,"You need to choose group!","Error",JOptionPane.ERROR_MESSAGE);
                }
                else if (groupChosen==null&& choice==2){
                    JOptionPane.showMessageDialog(frame,"You need to choose group!","Error",JOptionPane.ERROR_MESSAGE);
                }
                else if (itemChosen==null&& choice==2){
                    JOptionPane.showMessageDialog(frame,"You need to choose item!","Error",JOptionPane.ERROR_MESSAGE);
                }else {
                    int a = -3;
                    if (choice == 1) {
                        a = JOptionPane.showConfirmDialog(frame, "Are you sure to delete group " + groupChosen + " ?");
                    } else if (choice == 2) {
                        a = JOptionPane.showConfirmDialog(frame, "Are you sure to delete item " + itemChosen + " ?");
                    }
                    if (a == JOptionPane.YES_OPTION) {

                        if (choice == 1) {

                            shop.delArray(groupChosen);
                            sort.nameToMax (shop);
                             JOptionPane.showMessageDialog(frame,"Group "+groupChosen+" deleted!");

                            groupCQ.removeAllItems();
                            groupCQ.addItem("Choose a group");
                            for (Group group : shop.getGroupList()) {
                                groupCQ.addItem(group);
                            }

                            initCenterPanelStatisticsMenu();
                            initUpperPanelAddMenu();
                            initUpperPanelEditMenu();
                            initUpperPanelDeleteMenu();

                        } else if (choice == 2) {
                            groupChosen.delArray(itemChosen);
                            sort.nameToMax (shop);
                            JOptionPane.showMessageDialog(frame, "Item " + itemChosen + " deleted!");

                        }
                        frame.getContentPane().removeAll();
                        frame.add(upperPanelDelete, BorderLayout.CENTER);
                        clearChoicesDelete();
                        frame.add(lowerPanelDelete, BorderLayout.SOUTH);
                        frame.revalidate();
                        frame.repaint();

                    }
                }
            }
        });
    }


private void clearChoicesAdd(){
    nameTF.setText("");
    descriptionTA.setText("");
    manufacturerTF.setText("");
    choice=0;
    groupChosen=null;
    spinnerPrice.setValue(0);
    spinnerPriceCoin.setValue(0);
    groupOrItemAdd.setSelectedIndex(0);
    spinnerQuantity.setValue(0);
    choiceGroupAdd.setVisible(false);
    confirmAdd.setEnabled(false);
    nameTF.setEnabled(true);
    descriptionTA.setEnabled(true);
    manufacturerTF.setEnabled(true);
    spinnerPrice.setEnabled(true);
    spinnerPriceCoin.setEnabled(true);
    spinnerQuantity.setEnabled(true);
}


    private void clearChoicesEdit(){



        nameTF.setText("");
        oldName="";
        descriptionTA.setText("");
        manufacturerTF.setText("");
        choice=0;
        groupChosen=null;
        itemChosen=null;
        spinnerPrice.setValue(0);
        spinnerPriceCoin.setValue(0);
        groupOrItemEdit.setSelectedIndex(0);
        choiceGroupEdit.setVisible(false);
        choiceItemEdit.setVisible(false);

        nameTF.setEnabled(false);
        descriptionTA.setEnabled(false);
        manufacturerTF.setEnabled(false);
        spinnerPrice.setEnabled(false);
        spinnerPriceCoin.setEnabled(false);
        spinnerQuantity.setEnabled(false);
    }


    private void clearChoicesDelete(){
        groupOrItemDelete.setSelectedIndex(0);
        groupChosen=null;
        itemChosen=null;
    }


/////////////////////



    public static void main(String[] args) {
        Test data = new Test();
        Sort s = new Sort();
        Interface frame = new Interface(s.restoreShop());
        frame.setVisible(true);


    }

}