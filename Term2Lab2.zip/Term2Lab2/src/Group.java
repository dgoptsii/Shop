

public class Group {

    private String name;
    private String description;
    private Item [] ItemList = new Item [0];
    private Item [] helpArray = new Item [0];
    private int number;


    Group(){
        ItemList= new Item [0];
        this.name = "";
        this.description = "";
    }


    Group(String name, String description){
        ItemList= new Item [0];
        this.name = name;
        this.description = description;
    }


    Group (int size, String name, String description){
        ItemList= new Item [size];
        this.name = name;
        this.description = description;
    }



    public void setName (String name) {
        this.name= name;
    }


    public String getName () {
        return name	;
    }




    public void setDescription (String description) {
        this.description= description;
    }

    public String getDescription () {
        return description	;
    }




    public void setNumber (int num) {
        this.number = num;
    }


    public int getNumber () {
        return number;
    }


    public void addArray(Item item) {
        int size ;
        if (ItemList.length==0) {
            size=1;
        }

        else if (ItemList[0]!=null) {

            size = ItemList.length+1;
        }else {
            size=1;
        }

        helpArray = new Item [size];
        for (int i=0; i<size-1; i++) {
            helpArray [i]=ItemList[i];
        }
        helpArray [size-1]= item;

        ItemList = helpArray;

    }


    public void delArray(Item item) {
        int size = ItemList.length;
        String name = item.getName();
        int k=0;
        for (int i = 0; i<ItemList.length; i++) {
            if (name.equals(ItemList[i].getName())) {
                ItemList[i]=null;
                k=i;
                break;
            }
        }

        helpArray = new Item [size-1];
        if(size-1>0) {
            int j =0;
            for (int i=0; i<ItemList.length; i++) {
                if (ItemList[i]!=null) {
                    helpArray [j]=ItemList[i];
                }
                if (helpArray[j]!=null) {
                    j++;
                }
                if (j==helpArray.length) {
                    break;
                }

            }
        }
        ItemList = helpArray;
    }

    public Item[] getArray() {
        return ItemList;
    }

    public void setArray(Item[] newList) {
        this.ItemList=newList;
    }


    public int numberOfItems() {
        return ItemList.length;
    }



    /**returns full information about the group */
    public String getInfo() {
        String result = new String();
        result += "Name: "+name+"\nNumber of items: "+ItemList.length+"\n";
        result+="Description: "+description+" \n";
        return result;
    }

    /**returns list of items short information about them */
    public String getListOfItems(){
        String result = new String();
        if (ItemList.length>0) {
            int l = ItemList.length;
            for (int i =0; i<l;i++) {
                ItemList[i].setNumber(i+1);
                result += "\nItem №"+ItemList[i].getNumber()+": "+ItemList[i].getName()+"\n";

            }

        }
        else {
            result+="No items found!";
        }
        return result;
    }

    public String toString() {
        return name;
    }

}