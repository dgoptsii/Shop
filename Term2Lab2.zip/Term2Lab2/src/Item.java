

public class Item {

    private String name;
    private String description;
    private String manufacturer;
    private double price;
    private int amount=0;


    private int number;





    /** customized constructor of class Specialty*/
    Item (String name, String description,String manufacturer,  double price, int amount){
        this.name = name;
        this.description = description;
        this.manufacturer = manufacturer;
        this.price = price;
        this.amount=amount;

    }

    public Item() {

    }


    public void setName (String name) {
        this.name= name;
    }


    public String getName () {
        return name	;
    }


    public void setDescription (String description) {
        this.description= description;
    }


    public String getDescription () {
        return description;
    }



    public void setManufacturer (String manufacturer) {
        this.manufacturer= manufacturer;
    }


    public String getManufacturer () {
        return manufacturer;
    }


    public void setAmount (int amount) {
        this.amount= amount;
    }


    public int getAmount () {
        return amount;
    }

    public void setPrice (double price) {
        this.price= price;
    }


    public double getPrice () {
        return price;
    }


    public void setNumber (int num) {
        this.number = num;
    }



    public int getNumber () {
        return number;
    }

    /**returns short information about the item */
    public String getFullInfo(){
        String result = new String();

        result += "Name: "+name+"\n";
        result += "Description: "+description+"\n";
        result += "Manufacturer: "+manufacturer+"\n";
        result+="Quantity: "+amount+" \n";
        result+="Price: "+price+" \n";



        return result;
    }

    @Override
    public String toString() {
        return name;
    }


}