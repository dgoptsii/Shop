
import java.io.*;


public class Sort {

    private String[] array;



    /**
     * creates array of items according to their names in the alphabet order
     */
    private void sortName(Item[] items) {
        array = new String[items.length];

        for (int i = 0; i < items.length; i++) {

            array[i] = items[i].getName();
            String help = new String();
            for (int j = 0; j < array[i].length(); j++) {
                help += Character.toLowerCase(array[i].charAt(j));
            }
            array[i] = help;
        }


        ///change i
        for (int j = 0; j < array.length; j++) {
            String k = new String();

            for (int i = 0; i < array[j].length(); i++) {
                if (array[j].charAt(i) != 'і') {
                    k += array[j].charAt(i);
                } else {
                    k += "й*";
                }
            }
            array[j] = k;
        }


        ///change ї
        for (int j = 0; j < array.length; j++) {
            String k = new String();

            for (int i = 0; i < array[j].length(); i++) {
                if (array[j].charAt(i) != 'ї') {
                    k += array[j].charAt(i);
                } else {
                    k += "й+";
                }
            }
            array[j] = k;
        }


        ///change ґ
        for (int j = 0; j < array.length; j++) {
            String k = new String();

            for (int i = 0; i < array[j].length(); i++) {
                if (array[j].charAt(i) != 'ґ') {
                    k += array[j].charAt(i);
                } else {
                    k += "д%";
                }
            }
            array[j] = k;
        }
        ///change є
        for (int j = 0; j < array.length; j++) {
            String k = new String();

            for (int i = 0; i < array[j].length(); i++) {
                if (array[j].charAt(i) != 'є') {
                    k += array[j].charAt(i);
                } else {
                    k += "ж$";
                }
            }
            array[j] = k;
        }


        ///SORT
        for (int j = 0; j < array.length; j++) {
            for (int i = j + 1; i < array.length; i++) {
                if (array[i].compareTo(array[j]) < 0) {
                    String k = array[j];
                    array[j] = array[i];
                    array[i] = k;
                }
            }
        }


        ///////put і back
        for (int j = 0; j < array.length; j++) {
            String k = new String();

            for (int i = 0; i < array[j].length() - 1; i++) {
                if (array[j].charAt(i) == 'й' && array[j].charAt(i + 1) == '*') {
                    k += "і";
                    i++;
                } else {
                    k += array[j].charAt(i);
                }
            }
            if (array[j].charAt(array[j].length() - 1) != '*') {
                k += array[j].charAt(array[j].length() - 1);
            }

            array[j] = k;

        }

        ///////put ї back
        for (int j = 0; j < array.length; j++) {
            String k = new String();

            for (int i = 0; i < array[j].length() - 1; i++) {
                if (array[j].charAt(i) == 'й' && array[j].charAt(i + 1) == '+') {
                    k += "ї";
                    i++;
                } else {
                    k += array[j].charAt(i);
                }
            }
            if (array[j].charAt(array[j].length() - 1) != '+') {
                k += array[j].charAt(array[j].length() - 1);
            }
            array[j] = k;

        }

        ///////put є back
        for (int j = 0; j < array.length; j++) {
            String k = new String();

            for (int i = 0; i < array[j].length() - 1; i++) {
                if (array[j].charAt(i) == 'ж' && array[j].charAt(i + 1) == '$') {
                    k += "є";
                    i++;
                } else {
                    k += array[j].charAt(i);
                }
            }
            if (array[j].charAt(array[j].length() - 1) != '$') {
                k += array[j].charAt(array[j].length() - 1);
            }
            array[j] = k;

        }

        ///////put  г back
        for (int j = 0; j < array.length; j++) {
            String k = new String();

            for (int i = 0; i < array[j].length() - 1; i++) {
                if (array[j].charAt(i) == 'д' && array[j].charAt(i + 1) == '%') {
                    k += "ґ";
                    i++;
                } else {
                    k += array[j].charAt(i);
                }
            }
            if (array[j].charAt(array[j].length() - 1) != '%') {
                k += array[j].charAt(array[j].length() - 1);
            }
            array[j] = k;

        }

        for (int i = 0; i < items.length; i++) {

            String help = new String();
            for (int j = 0; j < array[i].length(); j++) {
                if (j == 0) {
                    help += Character.toUpperCase(array[i].charAt(j));
                } else {
                    help += array[i].charAt(j);
                }
            }
            array[i] = help;
        }
    }

    private void sortName(Group[] groups) {
        array = new String[groups.length];

        for (int i = 0; i < groups.length; i++) {

            array[i] = groups[i].getName();
            String help = new String();
            for (int j = 0; j < array[i].length(); j++) {
                help += Character.toLowerCase(array[i].charAt(j));
            }
            array[i] = help;
        }


        ///change i
        for (int j = 0; j < array.length; j++) {
            String k = new String();

            for (int i = 0; i < array[j].length(); i++) {
                if (array[j].charAt(i) != 'і') {
                    k += array[j].charAt(i);
                } else {
                    k += "й*";
                }
            }
            array[j] = k;
        }


        ///change ї
        for (int j = 0; j < array.length; j++) {
            String k = new String();

            for (int i = 0; i < array[j].length(); i++) {
                if (array[j].charAt(i) != 'ї') {
                    k += array[j].charAt(i);
                } else {
                    k += "й+";
                }
            }
            array[j] = k;
        }


        ///change ґ
        for (int j = 0; j < array.length; j++) {
            String k = new String();

            for (int i = 0; i < array[j].length(); i++) {
                if (array[j].charAt(i) != 'ґ') {
                    k += array[j].charAt(i);
                } else {
                    k += "д%";
                }
            }
            array[j] = k;
        }
        ///change є
        for (int j = 0; j < array.length; j++) {
            String k = new String();

            for (int i = 0; i < array[j].length(); i++) {
                if (array[j].charAt(i) != 'є') {
                    k += array[j].charAt(i);
                } else {
                    k += "ж$";
                }
            }
            array[j] = k;
        }


        ///SORT
        for (int j = 0; j < array.length; j++) {
            for (int i = j + 1; i < array.length; i++) {
                if (array[i].compareTo(array[j]) < 0) {
                    String k = array[j];
                    array[j] = array[i];
                    array[i] = k;
                }
            }
        }


        ///////put і back
        for (int j = 0; j < array.length; j++) {
            String k = new String();

            for (int i = 0; i < array[j].length() - 1; i++) {
                if (array[j].charAt(i) == 'й' && array[j].charAt(i + 1) == '*') {
                    k += "і";
                    i++;
                } else {
                    k += array[j].charAt(i);
                }
            }
            if (array[j].charAt(array[j].length() - 1) != '*') {
                k += array[j].charAt(array[j].length() - 1);
            }

            array[j] = k;

        }

        ///////put ї back
        for (int j = 0; j < array.length; j++) {
            String k = new String();

            for (int i = 0; i < array[j].length() - 1; i++) {
                if (array[j].charAt(i) == 'й' && array[j].charAt(i + 1) == '+') {
                    k += "ї";
                    i++;
                } else {
                    k += array[j].charAt(i);
                }
            }
            if (array[j].charAt(array[j].length() - 1) != '+') {
                k += array[j].charAt(array[j].length() - 1);
            }
            array[j] = k;

        }

        ///////put є back
        for (int j = 0; j < array.length; j++) {
            String k = new String();

            for (int i = 0; i < array[j].length() - 1; i++) {
                if (array[j].charAt(i) == 'ж' && array[j].charAt(i + 1) == '$') {
                    k += "є";
                    i++;
                } else {
                    k += array[j].charAt(i);
                }
            }
            if (array[j].charAt(array[j].length() - 1) != '$') {
                k += array[j].charAt(array[j].length() - 1);
            }
            array[j] = k;

        }

        ///////put  г back
        for (int j = 0; j < array.length; j++) {
            String k = new String();

            for (int i = 0; i < array[j].length() - 1; i++) {
                if (array[j].charAt(i) == 'д' && array[j].charAt(i + 1) == '%') {
                    k += "ґ";
                    i++;
                } else {
                    k += array[j].charAt(i);
                }
            }
            if (array[j].charAt(array[j].length() - 1) != '%') {
                k += array[j].charAt(array[j].length() - 1);
            }
            array[j] = k;

        }

        for (int i = 0; i < groups.length; i++) {

            String help = new String();
            for (int j = 0; j < array[i].length(); j++) {
                if (j == 0) {
                    help += Character.toUpperCase(array[i].charAt(j));
                } else {
                    help += array[i].charAt(j);
                }
            }
            array[i] = help;
        }
    }

    /** sorts array of items according to the array of names in alphabetic order */
    public Item[] nameToMax(Item[] items) {
        Item [] helpArr = new Item [items.length];

        sortName(items) ;
        for (int i=0; i<items.length; i++ ) {
            for (int j=0;j<items.length; j++) {
                if (items[j]!=null) {
                    String s1 = array[i];
                    String s2 = items[j].getName();


                    if (s1.equals(s2)) {
                        helpArr [i]=items[j];
                        items[j]=null;
                        break;
                    }
                }
            }
        }

        for (int k = 0; k<items.length; k++) {
            items [k]= helpArr[k];
        }
        return items;
    }

    /** sorts array of items according to the array of names in alphabetic order */
    public Group[] nameToMax(Group[] groups) {
        Group [] helpArr = new Group[groups.length];

        sortName(groups) ;
        for (int i=0; i<groups.length; i++ ) {
            for (int j=0;j<groups.length; j++) {
                if (groups[j]!=null) {
                    String s1 = array[i];
                    String s2 = groups[j].getName();


                    if (s1.equals(s2)) {
                        helpArr [i]=groups[j];
                        groups[j]=null;
                        break;
                    }
                }
            }
        }

        for (int k = 0; k<groups.length; k++) {
            groups [k]= helpArr[k];
        }
        return groups;
    }

    public void nameToMax (Shop shop){
        shop.setArray(nameToMax(shop.getArray()));
        for (int i=0;i<shop.getArray().length;i++){
            shop.getArray()[i].setArray(nameToMax(shop.getArray()[i].getArray()));
        }
    }

/////////////////////////////////////////////////////////////////////////////
    /**
     * returns an array of all items of Shop
     */
    public Item[] getAllItems(Shop shop) {
        int size = 0;
        Group[] groups = new Group[0];
        if(shop.getArray().length>0) {
            groups = shop.getArray();
            for (int j = 0; j < groups.length; j++) {
                size += groups[j].getArray().length;
            }
        }
        Item[] items = new Item[size];
        int k = 0;
        for (int i = 0; i < groups.length; i++) {
            if(groups[i].getArray().length>0) {
                for (int j = 0; j < groups[i].getArray().length; j++) {
                    items[k] = groups[i].getArray()[j];
                    if (k == size) {
                        break;
                    }
                    k++;
                }
            }
        }
        return items;
    }



    public Item[] findItem(String substring, Shop shop) {
        Item[] items = getAllItems(shop);
        Item[] found = new Item[items.length];
        String p="";
        for (int y=0; y<substring.length();y++){
            p += Character.toLowerCase(substring.charAt(y));
        }
        int c = 0;
        for (int i = 0; i < items.length; i++) {
            String s = "";
            for (int y=0; y<items[i].getName().length();y++){
                s += Character.toLowerCase(items[i].getName().charAt(y));
            }

            if (s.contains(p)) {
                found[c] = items[i];
                c++;
            }

        }
        Item[] foundItems = new Item[c];
        for (int i = 0; i < foundItems.length; i++) {
            foundItems[i] = found[i];
        }
        return foundItems;
    }


    /**
     * writes only lists of groups and items into one file
     */
    public void addToOneFileShort(Shop shop, String fileName) throws IOException {

        Group[] groups = shop.getGroupList();
        FileWriter fw = null;
        File file = new File("..\\Term2Lab2\\files\\" + fileName + ".txt");
        file.createNewFile();
        try {
            fw = new FileWriter(file);
            if(groups.length>0) {
                for (int i = 0; i < groups.length; i++) {
                    groups[i].setNumber(i + 1);
                    fw.write("/////GROUP â " + groups[i].getNumber() + ": " + groups[i].getName() + "/////\n");
                    fw.write(groups[i].getListOfItems());
                    fw.write("\n_____________________________________\n\n");
                }
            }
            if(groups.length==0){
                fw.write("There are no groups in the shop!");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                fw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }

    /**
     * writes full info about groups and items into one file
     */
    public void addToOneFileFull(Shop shop, String fileName) throws IOException {

        Group[] groups = shop.getGroupList();
        Item[] items = null;
        FileWriter fw = null;
        File file = new File("..\\Term2Lab2\\files\\" + fileName + ".txt");
        file.createNewFile();
        try {
            fw = new FileWriter(file);
            if(groups.length>0) {
                for (int i = 0; i < groups.length; i++) {
                    fw.write("_____________________________________\n");
                    groups[i].setNumber(i + 1);
                    fw.write("/////GROUP â " + groups[i].getNumber() + "/////\n");
                    fw.write(groups[i].getInfo());
                    fw.write("_____________________________________\n\n");
                    if (groups[i].getArray().length > 0) {
                        items = groups[i].getArray();
                        for (int j = 0; j < items.length; j++) {
                            items[j].setNumber(j + 1);
                            fw.write("Item â " + items[j].getNumber() + ":\n");
                            fw.write(items[j].getFullInfo() + "\n");
                        }
                    }
                }
            }
            if(groups.length==0){
                fw.write("There are no groups in the shop!");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                fw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * writes only lists of groups and items into separate files
     */
    public void addToDiffFilesShort(Shop shop, String name) throws IOException {

        Group[] groups = shop.getGroupList();
        int num = shop.getArray().length + 1;  //total number of files
        FileWriter[] fw = new FileWriter[num];

        File file = new File("..\\Term2Lab2\\files\\" + name + "_Groups.txt");
        file.createNewFile();
        try {
            fw[0] = new FileWriter(file);   //file with list of groups
            fw[0].write("LIST OF GROUPS:\n");
            fw[0].write(shop.toString());
            if(groups.length>0) {
                for (int i = 0; i < groups.length; i++) {
                    file = new File("..\\Term2Lab2\\files\\" + name + "_" + groups[i].getName() + ".txt");
                    file.createNewFile();    //files with lists of items
                    fw[i + 1] = new FileWriter(file);
                    fw[i + 1].write("List of items:\n");
                    fw[i + 1].write(groups[i].getListOfItems());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            for (int i = 0; i < num; i++) {
                try {
                    fw[i].close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }


    /**
     * writes full info about groups and items into separate files
     */
    public void addToDiffFilesFull(Shop shop, String name) throws IOException {

        Group[] groups = shop.getGroupList();
        Item[] items = null;
        int num = shop.getArray().length + 1;  //total number of files
        FileWriter[] fw = new FileWriter[num];

        File file = new File("..\\Term2Lab2\\files\\" + name + "_Groups.txt");
        file.createNewFile();
        try {
            fw[0] = new FileWriter(file);
            fw[0].write("LIST OF GROUPS:\n\n");
            if(groups.length==0){
                fw[0].write("There are no groups in the shop!");
            }
            if(groups.length>0) {
                for (int i = 0; i < groups.length; i++) {   //file with list of groups
                    groups[i].setNumber(i + 1);
                    fw[0].write("/////GROUP â " + groups[i].getNumber() + "/////\n");
                    fw[0].write(groups[i].getInfo() + "\n");
                }
                for (int i = 0; i < groups.length; i++) {
                    file = new File("..\\Term2Lab2\\files\\" + name + "_" + groups[i].getName() + ".txt");
                    file.createNewFile();
                    fw[i + 1] = new FileWriter(file);
                    fw[i + 1].write("List of items:\n\n");
                    if (groups[i].getArray().length > 0) {
                        items = groups[i].getArray();
                        for (int j = 0; j < items.length; j++) {   //files with lists of items
                            items[j].setNumber(j + 1);
                            fw[i + 1].write("Item â " + items[j].getNumber() + ":\n");
                            fw[i + 1].write(items[j].getFullInfo() + "\n");
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                for (int i = 0; i < num; i++)
                    fw[i].close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * checks if the name of the group is unigue, returns boolean
     */
    public boolean groupIsUnique(Shop shop, String group) {
        boolean b = true;
        if(shop.getArray().length>0) {
            Group[] groups = shop.getArray();
            String s1 = group.replaceAll("[\\s]{2,}", " ").toLowerCase(); //here we delete multiple spaces
            String s2 = null;
            String s3 = null;
            if (s1.endsWith(" ") || s1.startsWith(" ")) {   //here we delete the first and the last spaces if they exist
                s2 = s1.replaceAll("^ ", "");
                s3 = s2.replaceAll(" $", "");
            } else
                s3 = s1;

            for (int i = 0; i < groups.length; i++)
                if (s3.equals(groups[i].getName().toLowerCase())) {
                    b = false;
                    break;
                }
        }
        return b;

    }


    /**checks if the name of the item is unique, returns boolean*/
    public boolean itemIsUnique (Shop shop, String item){
        boolean b = true;
        if(shop.getArray().length>0) {
            Group[] groups = shop.getArray();
            Item[] items = null;
            String s1 = item.replaceAll("[\\s]{2,}", " ").toLowerCase(); //here we delete multiple spaces
            String s2 = null;
            String s3 = null;
            if (s1.endsWith(" ") || s1.startsWith(" ")) {   //here we delete the first and the last spaces if they exist
                s2 = s1.replaceAll("^ ", "");
                s3 = s2.replaceAll(" $", "");
            } else
                s3 = s1;

            for (int i = 0; i < groups.length; i++) {
                if (groups[i].getArray().length > 0) {
                    items = groups[i].getArray();
                    for (int j = 0; j < items.length; j++)
                        if (s3.equals(items[j].getName().toLowerCase())) {
                            b = false;
                            break;
                        }
                }
            }
        }
        return b;
    }


    /**returns the total cost of all items*/
    public double totalCost(Shop shop){
        Double res = 0.0;
        Sort s = new Sort();
        Item[] items = s.getAllItems(shop);
        if(items.length>0) {
            for (int i = 0; i < items.length; i++)
                res += items[i].getPrice() * items[i].getAmount();
        }
        return res;
    }


    /**returns the cost af items of a particular group*/
    public double costOfGroup(Group group){
        Double res = 0.0;
        Item[] items = new Item[group.getArray().length];
        if(items.length>0) {
            for (int i = 0; i < items.length; i++) {
                items[i] = group.getArray()[i];
                res += items[i].getPrice() * items[i].getAmount();
            }
        }
        return res;
    }


    /**returns an array of groups names*/
    public String[] getGroupsNames(Shop shop){
        Group[] groups = shop.getArray();
        String[] res = new String[groups.length];
        for(int i=0; i<res.length; i++)
            res[i] = groups[i].getName();

        return res;
    }


    /**returns an array of all items names*/
    public String[] getAllItemsNames(Shop shop){
        Sort s = new Sort();
        Item[] items = s.getAllItems(shop);
        String[] res = new String[items.length];
        if(items.length>0) {
            for (int i = 0; i < items.length; i++)
                res[i] = items[i].getName();
        }
        return res;
    }

    /**returns an array of all items prices*/
    public double[] getAllItemsPrices(Shop shop){
        Sort s = new Sort();
        Item[] items = s.getAllItems(shop);
        double[] res = new double[items.length];
        if(items.length>0) {
            for (int i = 0; i < items.length; i++)
                res[i] = items[i].getPrice();
        }
        return res;
    }


    /**returns an array of all items amounts*/
    public int[] getAllItemsAmounts(Shop shop){
        Sort s = new Sort();
        Item[] items = s.getAllItems(shop);
        int[] res = new int[items.length];
        if(items.length>0) {
            for (int i = 0; i < items.length; i++)
                res[i] = items[i].getAmount();
        }
        return res;
    }


    /**returns an array of items names of a particular group*/
    public String[] getGroupItemsNames(Group group){
        String[] res = new String[group.getArray().length];
        if(res.length>0) {
            for (int i = 0; i < res.length; i++)
                res[i] = group.getArray()[i].getName();
        }
        return res;
    }


    /**returns an array of items prices of a particular group*/
    public double[] getGroupItemsPrices(Group group){
        double[] res = new double[group.getArray().length];
        if(res.length>0) {
            for (int i = 0; i < res.length; i++)
                res[i] = group.getArray()[i].getPrice();
        }
        return res;
    }


    /**returns an array of items amounts of a particular group*/
    public int[] getGroupItemsAmounts(Group group){
        int[] res = new int[group.getArray().length];
        if(res.length>0) {
            for (int i = 0; i < res.length; i++)
                res[i] = group.getArray()[i].getAmount();
        }
        return res;
    }

    /**returns a matrix with info about !items!
     * !items! : if group == null -> all items in the shop
     *                       else -> items in this group
     * to be fitted into the statistics table*/
    public Object[][] tableBodyAllItems(Shop shop, Group group) {
        String[] allNames;
        double[] allPrices;
        int[] allAmounts;
        double[] totalSum;
        if(group == null){
            allNames = getAllItemsNames(shop);
            allPrices = getAllItemsPrices(shop);
            allAmounts = getAllItemsAmounts(shop);
            totalSum = getAllItemsCosts(shop);
        }else{
            allNames = getGroupItemsNames(group);
            allPrices = getGroupItemsPrices(group);
            allAmounts = getGroupItemsAmounts(group);
            totalSum = getGroupItemsCosts(group);
        }
        int column = allNames.length;
        Object[][] tableBody = new Object[column][4];
        for (int i = 0; i < column; i++) {
            tableBody[i][0] = allNames[i];
            tableBody[i][1] = allAmounts[i];
            tableBody[i][2] = allPrices[i];
            tableBody[i][3] = totalSum[i];
        }
        return tableBody;
    }

    /**returns an array of all items costs*/
    public double[] getAllItemsCosts(Shop shop){
        Sort s = new Sort();
        Item[] items = s.getAllItems(shop);
        double[] res = new double[items.length];
        if(res.length>0) {
            for (int i = 0; i < res.length; i++)
                res[i] = items[i].getPrice() * items[i].getAmount();
        }
        return res;
    }

    /**returns an array of items costs of a particular group*/
    public double[] getGroupItemsCosts(Group group){
        double[] res = new double[group.getArray().length];
        if(res.length>0) {
            for (int i = 0; i < res.length; i++)
                res[i] = group.getArray()[i].getAmount() * group.getArray()[i].getPrice();
        }
        return res;
    }


///////////////////
    /**saves database into a file to be able to restore it*/
    public void saveData(Shop shop) throws IOException {
        Group[] groups = shop.getGroupList();
        FileWriter fw = null;
        File file = new File("files/database.txt");
        file.createNewFile();
        String s = null;
        try {
            fw = new FileWriter(file);
            if(groups.length>0) {
                for (int i = 0; i < groups.length; i++) {
                    if(groups[i].getArray().length==0)
                        fw.write(groups[i].getName() + "ᎹᎹᎹ" + groups[i].getDescription() + "ጴጴጴ");
                    if(groups[i].getArray().length>0) {
                        fw.write(groups[i].getName() + "ᎹᎹᎹ" + groups[i].getDescription() + "ᖓᖓᖓ");
                        for (int j = 0; j < groups[i].getArray().length; j++) {
                            fw.write(groups[i].getArray()[j].getName() + "ᎹᎹᎹ");
                            fw.write(groups[i].getArray()[j].getDescription() + "ᎹᎹᎹ");
                            fw.write(groups[i].getArray()[j].getManufacturer() + "ᎹᎹᎹ");
                            fw.write(s.valueOf(groups[i].getArray()[j].getPrice()) + "ᎹᎹᎹ");
                            fw.write(s.valueOf(groups[i].getArray()[j].getAmount()));
                            if (j < groups[i].getArray().length - 1 && i <= groups.length - 1) //розділювач між об'єктами
                                fw.write("ᖓᖓᖓ");
                            else if (j == groups[i].getArray().length - 1 && i < groups.length - 1) //розділювач між групами
                                fw.write("ጴጴጴ");
                            else if (j == groups[i].getArray().length - 1 && i == groups.length - 1) //останній об'єкт, нічого не записує
                                break;
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                fw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //ጴጴጴ  групи
    //ᖓᖓᖓ  об'єкти
    //ᎹᎹᎹ  властивості


    /**returns a shop from info in file database.txt*/
    public Shop restoreShop(){
        Shop shop = new Shop();
        File file = new File("files/database.txt");
        BufferedReader br = null;
        FileInputStream fis = null;;
        InputStreamReader isr = null;
        String s = "";  //вхідна стрічка
        String[] sGroups = null;
        String[] sObjects = null;
        String[] sFeatures = null;
        double price = 0;
        int amount = 0;
        Group[] groups = null;
        Item[] items = null;
        try {
            fis = new FileInputStream(file);
            isr = new InputStreamReader(fis, "UTF-8");
            br = new BufferedReader(isr);
            s = br.readLine();
            sGroups = s.split("ጴጴጴ"); //розбиваємо на групи товарів
            groups = new Group[sGroups.length];
            for(int i=0; i<groups.length; i++){
                sObjects = sGroups[i].split("ᖓᖓᖓ"); //розбиваємо на об'єкти
                sFeatures = sObjects[0].split("ᎹᎹᎹ"); //розбиваємо перший об'єкт(групу) на властивості
                groups[i] = new Group();
                groups[i].setName(sFeatures[0]);
                groups[i].setDescription(sFeatures[1]);
                shop.addArray(groups[i]);
                items = new Item[sObjects.length-1];
                if(sGroups[i].length()>1) {
                    for (int j = 0; j < sObjects.length-1; j++) {
                        sFeatures = sObjects[j+1].split("ᎹᎹᎹ"); //розбиваємо об'єкти(вже товари) на властивості
                        items[j] = new Item();
                        items[j].setName(sFeatures[0]);
                        items[j].setDescription(sFeatures[1]);
                        items[j].setManufacturer(sFeatures[2]);
                        price = Double.parseDouble(sFeatures[3]);
                        items[j].setPrice(price);
                        amount = Integer.parseInt(sFeatures[4]);
                        items[j].setAmount(amount);
                        groups[i].addArray(items[j]);
                    }
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        finally{
            try {
                fis.close();
                isr.close();
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return shop;
    }
}

