
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public final class DataInput {

    /** reads and returns long   */
    public static Long getLong() throws IOException{
        String s = getString();
        Long value = Long.valueOf(s);
        return value;
    }

    /** reads and returns char */
    public static char getChar() throws IOException{
        String s = getString();
        while (s.length()>1) {
            System.out.println("Enter only one letter: ");
            s = getString();
        }
        return s.charAt(0);
    }

    /** reads and returns int*/
    public static Integer getInt(){
        String s = "";
        try {
            s = getString();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        Integer value = Integer.valueOf(s);
        return value;

    }

    /**reads and returns String */
    public static String getString() throws IOException{
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);
        String s = br.readLine();
        return s;
    }

}