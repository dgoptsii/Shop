

public class Shop {



    private Group [] groupList = new Group [0];
    private Group [] helpArray = new Group [0];
    private final String name = "Shop";
    private Sort sort = new Sort();


    Shop(){
        groupList= new Group [0];

    }


    Shop(int size){
        groupList= new Group [size];

    }



    /** add group to groupList  */
    public void addArray(Group group) {
        int size ;
        if (groupList.length==0) {
            size=1;
        }

        else if (groupList[0]!=null) {

            size = groupList.length+1;
        }else {
            size=1;
        }

        helpArray = new Group [size];
        for (int i=0; i<size-1; i++) {
            helpArray [i]=groupList[i];
        }
        helpArray [size-1]= group;
        groupList = helpArray;
    }


    /** delete group to groupList*/
    public void delArray(Group group) {
        int size = groupList.length;
        String name = group.getName();
        int k=0;
        for (int i = 0; i<groupList.length; i++) {
            if (name.equals(groupList[i].getName())) {
                groupList[i]=null;
                k=i;
                break;
            }
        }

        helpArray = new Group [size-1];
        if(size-1>0) {
            int j =0;
            for (int i=0; i<groupList.length; i++) {
                if (groupList[i]!=null) {
                    helpArray [j]=groupList[i];
                }
                if (helpArray[j]!=null) {
                    j++;
                }
                if (j==helpArray.length) {
                    break;
                }

            }
        }
        groupList = helpArray;

    }


    /**returns array of groups */
    public Group[] getArray() {
        return groupList;
    }


    public void setArray(Group[] newList) {
        this.groupList=newList;
    }


    /**returns list of groups with short information about them */
    public String toString() {
        String result = new String();
        if (groupList.length>0) {
            int l = groupList.length;
            for (int i =0; i<l;i++) {
                groupList[i].setNumber(i+1);
                result += "\nGroup №"+groupList[i].getNumber()+": "+groupList[i].getName()+" \n";
            }
        }else {
            result+="No groups found!";
        }
        return result;
    }


    public Group[] getGroupList() {
        return groupList;
    }

}